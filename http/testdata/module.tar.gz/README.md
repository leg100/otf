# OTF terraform test module

A module hosted on github purely for the purposes of testing the functionality of OTF's module registry.
